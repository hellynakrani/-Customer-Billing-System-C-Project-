#include <stdio.h>
#include "customer.h"

int main() {
    int choice, id;

    do {
        printf("\n===== Customer Billing System =====\n");
        printf("1. Add Customer\n");
        printf("2. View All Customers\n");
        printf("3. Search Customer by ID\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addCustomer();
                break;
            case 2:
                viewCustomers();
                break;
            case 3:
                printf("Enter Customer ID to search: ");
                scanf("%d", &id);
                searchCustomer(id);
                break;
            case 4:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 4);

    return 0;
}
