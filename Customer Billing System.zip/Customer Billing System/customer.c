#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "customer.h"

void addCustomer() {
    Customer c;
    FILE *fp = fopen("bills.txt", "a");
    if (fp == NULL) {
        printf("Error opening file!\n");
        return;
    }

    printf("Enter Customer ID: ");
    scanf("%d", &c.id);
    printf("Enter Customer Name: ");
    // Corrected to read the whole name with spaces.
    scanf(" %[^\n]", c.name);  
    printf("Enter Units Consumed: ");
    scanf("%d", &c.units);

    c.bill = calculateBill(c.units);

    // Writing the customer data to the file
    fwrite(&c, sizeof(Customer), 1, fp);
    fclose(fp);
    printf("\nCustomer Added Successfully!\n\n");
}

void viewCustomers() {
    Customer c;
    FILE *fp = fopen("bills.txt", "r");
    if (fp == NULL) {
        printf("No data found.\n");
        return;
    }

    printf("\n%-10s %-20s %-10s %-10s\n", "ID", "Name", "Units", "Bill");
    printf("-----------------------------------------------------------\n");
    while (fread(&c, sizeof(Customer), 1, fp)) {
        // Printing the customer details
        printf("%-10d %-20s %-10d ₹%-10.2f\n", c.id, c.name, c.units, c.bill);
    }
    fclose(fp);
    printf("\n");
}

void searchCustomer(int id) {
    Customer c;
    int found = 0;
    FILE *fp = fopen("bills.txt", "r");
    if (fp == NULL) {
        printf("No data found.\n");
        return;
    }

    while (fread(&c, sizeof(Customer), 1, fp)) {
        if (c.id == id) {
            printf("\nCustomer Found:\n");
            printf("ID: %d\nName: %s\nUnits: %d\nBill: ₹%.2f\n\n", c.id, c.name, c.units, c.bill);
            found = 1;
            break;  
        }
    }
    if (!found) {
        printf("\nCustomer with ID %d not found.\n\n", id);
    }
    fclose(fp);
}

float calculateBill(int units) {
    float bill = 0;
    if (units <= 100)
        bill = units * 0.75;
    else if (units <= 300)
        bill = 75 + (units - 100) * 1.50;
    else if (units <= 500)
        bill = 275 + (units - 300) * 1.85;
    else
        bill = 575 + (units - 500) * 2.50;
    return bill;
}
