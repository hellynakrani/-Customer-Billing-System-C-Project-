#ifndef CUSTOMER_H
#define CUSTOMER_H

#define MAX 100

// Structure to store customer details
typedef struct {
    int id;
    char name[50];
    int units;
    float bill;
} Customer;

// Function declarations
void addCustomer();
void viewCustomers();
void searchCustomer(int id);
float calculateBill(int units);

#endif
